QuickCalc v1.0.0 - Structural Beam Analysis
================================================

This package contains QuickCalc for Windows.

Contents:
- quickcalc_backend.exe: Python FEA calculation engine
- QuickCalc-1.0.msi: JavaFX frontend installer

Installation:
1. Run QuickCalc-1.0.msi to install the application
2. The backend executable will be used automatically

Manual Testing:
- Test backend: quickcalc_backend.exe test

For more information, visit: https://github.com/your-username/QuickCalc
